'use strict';

import initMap from './modules/map';

document.addEventListener('DOMContentLoaded', () => {
    initMap('#map');
});